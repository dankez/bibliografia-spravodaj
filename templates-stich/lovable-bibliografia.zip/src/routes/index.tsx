import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, FileText, Map, RotateCcw, ExternalLink, Quote } from "lucide-react";

import { articles, STATS, LOCATIONS, type Article } from "@/data/articles";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bibliografia SSS — archív Spravodaja Slovenskej speleologickej spoločnosti" },
      {
        name: "description",
        content:
          "Digitálny bibliografický archív Slovenskej speleologickej spoločnosti. Vyhľadávajte v 3802 článkoch Spravodaja SSS z rokov 1970–2026 podľa autora, jaskyne, roku či čísla.",
      },
      { property: "og:title", content: "Bibliografia SSS — archív Spravodaja" },
      {
        property: "og:description",
        content:
          "Vyhľadávajte v 3802 článkoch Spravodaja SSS z rokov 1970–2026 podľa autora, jaskyne, roku či čísla.",
      },
    ],
  }),
  component: Index,
});

const ISSUES = [1, 2, 3, 4] as const;

function Index() {
  const [query, setQuery] = useState("");
  const [yearFrom, setYearFrom] = useState(STATS.yearFrom);
  const [yearTo, setYearTo] = useState(STATS.yearTo);
  const [activeIssues, setActiveIssues] = useState<number[]>([]);
  const [mapsOnly, setMapsOnly] = useState(false);
  const [fulltext, setFulltext] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(articles[3].id);

  const toggleIssue = (n: number) =>
    setActiveIssues((prev) => (prev.includes(n) ? prev.filter((i) => i !== n) : [...prev, n]));

  const reset = () => {
    setQuery("");
    setYearFrom(STATS.yearFrom);
    setYearTo(STATS.yearTo);
    setActiveIssues([]);
    setMapsOnly(false);
    setFulltext(false);
  };

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return articles.filter((a) => {
      if (a.year < yearFrom || a.year > yearTo) return false;
      if (activeIssues.length && !activeIssues.includes(a.issue)) return false;
      if (mapsOnly && !a.isMap) return false;
      if (q) {
        const haystack = fulltext
          ? `${a.title} ${a.author} ${a.description} ${a.keywords.join(" ")}`
          : `${a.title} ${a.author} ${a.keywords.join(" ")}`;
        if (!haystack.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [query, yearFrom, yearTo, activeIssues, mapsOnly, fulltext]);

  const selected = results.find((a) => a.id === selectedId) ?? null;
  const isDefault = !query && !activeIssues.length && !mapsOnly && yearFrom === STATS.yearFrom && yearTo === STATS.yearTo;

  return (
    <div className="flex h-screen flex-col font-sans">
      {/* Header */}
      <header className="z-20 flex flex-col gap-4 border-b border-border bg-background px-6 py-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 flex-col">
          <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.25em] text-accent">
            Digitálna bibliografia
          </span>
          <h1 className="font-serif text-xl font-semibold leading-tight text-foreground sm:text-2xl">
            Slovenská speleologická spoločnosť
          </h1>
          <p className="text-sm text-muted-foreground">Spravodaj SSS · články, autori a bibliografické odkazy</p>
        </div>
        <dl className="grid grid-cols-2 gap-x-8 gap-y-2 sm:grid-cols-4">
          <Stat label="Článkov" value={STATS.articles.toLocaleString("sk")} />
          <Stat label="Roky" value={`${STATS.yearFrom}–${STATS.yearTo}`} />
          <Stat label="Mapy/plány" value={STATS.maps.toLocaleString("sk")} />
          <Stat label="Autori" value={STATS.authors.toLocaleString("sk")} />
        </dl>
      </header>

      <main className="flex flex-1 overflow-hidden">
        {/* Zone 1: filters */}
        <aside className="hidden w-72 shrink-0 overflow-y-auto border-r border-border bg-sidebar p-6 lg:block">
          <div className="space-y-8">
            <div>
              <label className="relative block">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Hľadať autora, jaskyňu, tému…"
                  className="w-full rounded-md border border-input bg-card py-2.5 pl-9 pr-3 text-sm outline-none ring-ring/30 transition-shadow focus:ring-2"
                />
              </label>
              <label className="mt-3 flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
                <input
                  type="checkbox"
                  checked={fulltext}
                  onChange={(e) => setFulltext(e.target.checked)}
                  className="size-4 accent-accent"
                />
                Hľadať vo fulltexte
              </label>
            </div>

            <Section title="Obdobie">
              <div className="flex items-center justify-between text-sm">
                <span className="font-mono font-medium text-foreground">
                  {yearFrom} – {yearTo}
                </span>
                <button
                  onClick={reset}
                  className="flex items-center gap-1 text-xs font-medium text-accent hover:underline"
                >
                  <RotateCcw className="size-3" /> Reset
                </button>
              </div>
              <div className="mt-3 space-y-3">
                <RangeSlider
                  label="Od"
                  min={STATS.yearFrom}
                  max={STATS.yearTo}
                  value={yearFrom}
                  onChange={(v) => setYearFrom(Math.min(v, yearTo))}
                />
                <RangeSlider
                  label="Do"
                  min={STATS.yearFrom}
                  max={STATS.yearTo}
                  value={yearTo}
                  onChange={(v) => setYearTo(Math.max(v, yearFrom))}
                />
              </div>
            </Section>

            <Section title="Číslo ročníka">
              <div className="grid grid-cols-4 gap-2">
                {ISSUES.map((n) => {
                  const active = activeIssues.includes(n);
                  return (
                    <button
                      key={n}
                      onClick={() => toggleIssue(n)}
                      className={`rounded-md border py-2 text-sm font-medium transition-colors ${
                        active
                          ? "border-accent bg-accent text-accent-foreground"
                          : "border-input bg-card text-foreground hover:border-accent/60"
                      }`}
                    >
                      č. {n}
                    </button>
                  );
                })}
              </div>
              <label className="mt-3 flex cursor-pointer items-center gap-2 text-sm text-foreground">
                <input
                  type="checkbox"
                  checked={mapsOnly}
                  onChange={(e) => setMapsOnly(e.target.checked)}
                  className="size-4 accent-accent"
                />
                <Map className="size-4 text-muted-foreground" />
                Iba mapy / plány
              </label>
            </Section>

            <Section title="Lokality">
              <div className="space-y-1.5">
                {LOCATIONS.map((loc) => (
                  <button
                    key={loc}
                    onClick={() => setQuery(loc)}
                    className="block text-left text-sm text-foreground transition-colors hover:text-accent"
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </Section>
          </div>
        </aside>

        {/* Zone 2: results */}
        <section className="flex-1 overflow-y-auto bg-background p-6 sm:p-8">
          <div className="mx-auto max-w-3xl">
            <div className="mb-6 flex items-center justify-between border-b border-border pb-4">
              <h2 className="text-sm text-muted-foreground">
                {isDefault ? "Najnovšie záznamy" : "Výsledky hľadania"} ·{" "}
                <span className="font-medium text-foreground">{results.length}</span> záznamov
              </h2>
              {!isDefault && (
                <button onClick={reset} className="text-xs font-medium text-accent hover:underline">
                  Zrušiť filtre
                </button>
              )}
            </div>

            {results.length === 0 ? (
              <p className="py-16 text-center text-sm text-muted-foreground">
                Žiadne záznamy nezodpovedajú zadaným filtrom.
              </p>
            ) : (
              <div className="space-y-4">
                {results.map((a) => (
                  <ResultCard
                    key={a.id}
                    article={a}
                    selected={a.id === selectedId}
                    onSelect={() => setSelectedId(a.id)}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Zone 3: detail */}
        <aside className="hidden w-[400px] shrink-0 overflow-y-auto border-l border-border bg-surface p-8 xl:block">
          {selected ? (
            <DetailPane key={selected.id} article={selected} />
          ) : (
            <p className="mt-24 text-center text-sm text-muted-foreground">Vyberte článok zo zoznamu.</p>
          )}
        </aside>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <dt className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="font-mono text-sm font-semibold text-accent">{value}</dd>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="mb-3 font-mono text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
        {title}
      </h3>
      {children}
    </section>
  );
}

function RangeSlider({
  label,
  min,
  max,
  value,
  onChange,
}: {
  label: string;
  min: number;
  max: number;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="flex items-center gap-3 text-xs text-muted-foreground">
      <span className="w-5 shrink-0 font-mono">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1 w-full cursor-pointer appearance-none rounded-full bg-border accent-accent"
      />
    </label>
  );
}

function ResultCard({
  article,
  selected,
  onSelect,
}: {
  article: Article;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      onClick={onSelect}
      className={`group relative block w-full rounded-xl border bg-card p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-sm ${
        selected ? "border-accent ring-1 ring-accent/40" : "border-border"
      }`}
    >
      {selected && (
        <span className="absolute -left-px top-5 h-12 w-1 rounded-full bg-accent" aria-hidden />
      )}
      <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] font-semibold uppercase tracking-wider text-accent">
        <span>{article.year}</span>
        <span className="text-border">/</span>
        <span>č. {article.issue}</span>
        <span className="text-border">/</span>
        <span>s. {article.page}</span>
        {article.isMap && (
          <span className="ml-auto flex items-center gap-1 rounded-full bg-accent/10 px-2 py-0.5 text-accent">
            <Map className="size-3" /> Mapa
          </span>
        )}
      </div>
      <h3 className="mb-2 text-balance font-serif text-xl font-medium leading-tight text-foreground transition-colors group-hover:text-accent">
        {article.title}
      </h3>
      <p className="text-sm text-muted-foreground">{article.author}</p>
    </button>
  );
}

function DetailPane({ article }: { article: Article }) {
  return (
    <div className="animate-entry">
      <div className="mb-2 flex flex-wrap items-center gap-x-3 font-mono text-[10px] font-semibold uppercase tracking-wider text-accent">
        <span>{article.year}</span>
        <span className="text-border">/</span>
        <span>č. {article.issue}</span>
        <span className="text-border">/</span>
        <span>s. {article.page}</span>
      </div>
      <h2 className="mb-6 text-balance font-serif text-2xl font-medium leading-tight text-foreground">
        {article.title}
      </h2>

      <div className="grid grid-cols-2 gap-4 border-y border-border py-5">
        <Meta label="Autor" value={article.author} />
        <Meta label="Typ" value={article.isMap ? "Mapa / plán" : "Článok"} />
      </div>

      <div className="py-5">
        <p className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Abstrakt
        </p>
        <p className="text-pretty text-sm leading-relaxed text-foreground/85">{article.description}</p>
      </div>

      <div className="border-t border-border py-5">
        <p className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Kľúčové slová
        </p>
        <div className="flex flex-wrap gap-2">
          {article.keywords.map((k) => (
            <span key={k} className="rounded-full border border-border bg-card px-2.5 py-0.5 text-xs text-foreground">
              {k}
            </span>
          ))}
        </div>
      </div>

      <div className="space-y-2 pt-2">
        <a
          href="#"
          className="flex w-full items-center justify-center gap-2 rounded-md bg-primary py-3 text-sm font-medium text-primary-foreground transition-transform hover:-translate-y-px"
        >
          <ExternalLink className="size-4" /> Otvoriť PDF v novej karte
        </a>
        <button className="flex w-full items-center justify-center gap-2 rounded-md border border-border bg-card py-3 text-sm font-medium text-foreground transition-colors hover:border-accent/60">
          <Quote className="size-4" /> Kopírovať citáciu (ISO 690)
        </button>
        <p className="pt-2 text-center text-xs leading-relaxed text-muted-foreground">
          <FileText className="mr-1 inline size-3" />
          Odkaz smeruje priamo na fyzickú stranu článku, ak je v databáze dostupný offset PDF strany.
        </p>
      </div>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="mb-1 font-mono text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </p>
      <p className="text-sm text-foreground">{value}</p>
    </div>
  );
}
