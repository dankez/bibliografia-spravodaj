---
name: Modern Academic
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#040057'
  on-tertiary: '#ffffff'
  tertiary-container: '#0d0093'
  on-tertiary-container: '#7f82ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

This design system is built for the high-density information environment of a digital bibliography portal. The brand personality is **scholarly, authoritative, and frictionless**. It moves away from the "dusty archive" trope, favoring a "Modern Academic" aesthetic that prioritizes the researcher's cognitive load.

The design style is **Sophisticated Minimalism**. It utilizes expansive whitespace to denote intellectual breathing room, combined with precise, high-contrast typography to ensure that complex citations remain legible during long-form research sessions. The emotional response should be one of quiet confidence, reliability, and precision.

## Colors

The palette is anchored in high-contrast clarity.
- **Primary (Slate/Charcoal):** Used for primary text and structural elements to provide a grounded, authoritative feel.
- **Secondary (Emerald Green):** A vibrant yet professional accent used for primary actions, success states, and verified citation badges.
- **Tertiary (Indigo):** Reserved for links, secondary call-to-actions, and interactive data points.
- **Surface (Neutral):** A crisp, ultra-light gray/white (`#F8FAFC`) is used for backgrounds to reduce eye strain compared to pure white, while maintaining maximum contrast for the deep slate text.

## Typography

Typography is the core of this design system.
- **Headings:** Use **Playfair Display**. It provides the "scholarly" weight and editorial character needed for title-heavy pages.
- **Body & Data:** Use **Inter**. Chosen for its exceptional legibility in high-density lists and its neutral, systematic feel.
- **Citations:** Bibliography entries should use `body-md` for the main text, with authors and titles differentiated by weight rather than font change to maintain a clean scan-line.

## Layout & Spacing

The layout follows a **Fixed Grid** model for desktop to ensure comfortable line lengths for reading research data. 

- **Desktop:** 12-column grid, 1280px max-width, 24px gutters. Content is centered with generous outer margins to focus the eye.
- **Tablet:** 8-column grid with 16px gutters and 24px side margins.
- **Mobile:** 4-column fluid grid. Headings scale down using defined mobile variables to prevent orphans and excessive wrapping.
- **Rhythm:** A 4px baseline grid ensures vertical harmony between text-heavy components.

## Elevation & Depth

This design system uses **Tonal Layers** and **Ambient Shadows** to create a focused hierarchy without visual clutter.

- **Surface Levels:** The main background is level 0. Cards and search bars occupy level 1, using a very subtle, diffused shadow (0px 4px 20px rgba(15, 23, 42, 0.05)) to lift them slightly.
- **Active States:** Elements being interacted with (e.g., a selected citation) use a thin, 1px inset border of the secondary color rather than a heavy shadow.
- **Backdrop:** Modals and overlays use a light backdrop blur (8px) with a semi-transparent slate overlay to maintain context while focusing the user.

## Shapes

The shape language is **Rounded**. This softens the "industrial" feel of data-heavy portals, making the interface more approachable and modern. 

- **Standard Elements:** 0.5rem (8px) for buttons, input fields, and small chips.
- **Containers:** 1rem (16px) for cards and modals.
- **Interactive Elements:** Use consistent rounding to ensure focus states follow the component geometry perfectly.

## Components

- **Buttons:** Primary buttons use the secondary emerald green with white text. Hover states involve a slight darkening of the fill. Secondary buttons use a slate outline.
- **Search Bar:** A prominent component. It should be oversized with a level 1 elevation and a persistent tertiary indigo focus ring.
- **Citations Cards:** Use generous padding (24px). The title of the work uses `headline-md`, while the metadata (date, publisher) uses `body-sm` in a secondary text color.
- **Chips/Tags:** Used for "Keywords" or "Subjects." These are low-contrast (light slate background) with `label-sm` text to keep them from competing with primary content.
- **Data Tables:** Striping is avoided in favor of subtle border-bottom dividers (1px, `#E2E8F0`) to maintain a clean, "paper-like" aesthetic.
- **Focus States:** High-visibility 2px indigo rings with a 2px offset are mandatory for accessibility.