export interface Article {
  id: number;
  year: number;
  issue: 1 | 2 | 3 | 4;
  page: string;
  title: string;
  author: string;
  description: string;
  isMap: boolean;
  keywords: string[];
  pdfPage?: number;
}

export const STATS = {
  articles: 3802,
  yearFrom: 1970,
  yearTo: 2026,
  maps: 575,
  authors: 676,
};

export const articles: Article[] = [
  {
    id: 1,
    year: 2026,
    issue: 1,
    page: "103",
    title: "Spoločenské správy / Aktuality",
    author: "Redakcia",
    description:
      "Rubrika prináša spoločenské správy a aktuálne informácie zo života Slovenskej speleologickej spoločnosti.",
    isMap: false,
    keywords: ["aktuality", "SSS", "spoločnosť"],
    pdfPage: 103,
  },
  {
    id: 2,
    year: 2026,
    issue: 1,
    page: "102",
    title: "Najhlbšie jaskyne Slovenska, stav k 1. 3. 2026",
    author: "Redakcia",
    description: "Tabuľkový prehľad najhlbších jaskýň Slovenska podľa stavu k 1. marcu 2026.",
    isMap: false,
    keywords: ["hĺbka", "rebríček", "jaskyne Slovenska"],
    pdfPage: 102,
  },
  {
    id: 3,
    year: 2026,
    issue: 1,
    page: "99-100",
    title: "Prehľad činnosti skupín a klubov SSS v roku 2025",
    author: "Redakcia",
    description:
      "Súhrnný prehľad činnosti skupín a klubov Slovenskej speleologickej spoločnosti v roku 2025.",
    isMap: false,
    keywords: ["činnosť", "kluby", "ročenka"],
    pdfPage: 99,
  },
  {
    id: 4,
    year: 2025,
    issue: 4,
    page: "12-18",
    title: "Nové poznatky o hydrogeológii Demänovského jaskynného systému",
    author: "Peter Holúbek, Ján Tulis",
    description:
      "Príspevok sumarizuje výsledky merania prietokov a chemizmu podzemných vôd v oblasti Demänovských jaskýň a potvrdzuje prepojenie povrchových tokov s hlbokým krasovým obehom.",
    isMap: false,
    keywords: ["Demänovská dolina", "hydrogeológia", "kras"],
    pdfPage: 12,
  },
  {
    id: 5,
    year: 2024,
    issue: 2,
    page: "45-62",
    title: "Morfoštruktúrna analýza krasového reliéfu Silickej planiny",
    author: "Ladislav Novotný",
    description:
      "Analýza vplyvu tektoniky a litológie na vývoj povrchových krasových foriem v centrálnej časti Silickej planiny.",
    isMap: true,
    keywords: ["Slovenský kras", "Silická planina", "morfológia"],
    pdfPage: 45,
  },
  {
    id: 6,
    year: 2022,
    issue: 3,
    page: "78-90",
    title: "Speleoklimatický výskum Demänovskej ľadovej jaskyne",
    author: "Pavol Herich, Martin Bella",
    description:
      "Dlhodobý monitoring teploty a vlhkosti vzduchu v ľadovej časti jaskyne a jeho súvislosť so zachovaním ľadovej výplne.",
    isMap: false,
    keywords: ["mikroklíma", "ľad", "monitoring"],
    pdfPage: 78,
  },
  {
    id: 7,
    year: 2018,
    issue: 2,
    page: "12-18",
    title: "Genéza a morfológia jaskýň vápencového masívu Ohnište",
    author: "Ján Holúbek",
    description:
      "Geomorfologický prieskum centrálnej časti Ohnišťa, analýza vplyvu tektoniky na smerovanie chodieb a popis novozistených sintrových foriem.",
    isMap: true,
    keywords: ["Ohnište", "Nízke Tatry", "speleogenéza"],
    pdfPage: 12,
  },
  {
    id: 8,
    year: 2012,
    issue: 4,
    page: "102",
    title: "Nové objavy v Jaskyni zlomov na severnom svahu Nízkych Tatier",
    author: "Štefan Mlynárik",
    description:
      "Správa o objavení nových priestorov a meračských prácach v Jaskyni zlomov vrátane predbežnej mapovej dokumentácie.",
    isMap: true,
    keywords: ["Nízke Tatry", "objav", "mapovanie"],
    pdfPage: 102,
  },
  {
    id: 9,
    year: 2005,
    issue: 1,
    page: "33-40",
    title: "Prieskum priepasti Brázda a jej genéza",
    author: "Anton Droppa",
    description:
      "Historický prieskum a meračská dokumentácia priepasti Brázda v Slovenskom krase s diskusiou o jej vzniku.",
    isMap: false,
    keywords: ["Slovenský kras", "priepasť", "genéza"],
    pdfPage: 33,
  },
  {
    id: 10,
    year: 1994,
    issue: 3,
    page: "5-11",
    title: "Korózia a inkrustácia v jaskyniach Malých Karpát",
    author: "Peter Magdolen",
    description:
      "Štúdia chemických procesov tvorby a rozpúšťania sintrových útvarov vo vybraných jaskyniach Malých Karpát.",
    isMap: false,
    keywords: ["Malé Karpaty", "sinter", "korózia"],
    pdfPage: 5,
  },
  {
    id: 11,
    year: 1988,
    issue: 2,
    page: "20-29",
    title: "Mapová dokumentácia Belianskej jaskyne",
    author: "Kolektív autorov",
    description:
      "Aktualizovaný polygónový ťah a pôdorysná mapa sprístupnenej časti Belianskej jaskyne v Belianskych Tatrách.",
    isMap: true,
    keywords: ["Belianske Tatry", "mapa", "dokumentácia"],
    pdfPage: 20,
  },
  {
    id: 12,
    year: 1976,
    issue: 1,
    page: "8-15",
    title: "Z histórie jaskyniarstva na Slovensku",
    author: "Redakcia",
    description:
      "Prehľadová štúdia o začiatkoch organizovaného jaskyniarstva a vzniku speleologických skupín na Slovensku.",
    isMap: false,
    keywords: ["história", "jaskyniarstvo", "Slovensko"],
    pdfPage: 8,
  },
];

export const LOCATIONS = [
  "Demänovská dolina",
  "Slovenský kras",
  "Malé Karpaty",
  "Belianske Tatry",
  "Nízke Tatry",
];
