---
name: Archival Scholarly System
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e8'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#5a413e'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#8d706d'
  outline-variant: '#e1bebb'
  surface-tint: '#b2292a'
  primary: '#ac2326'
  on-primary: '#ffffff'
  primary-container: '#ce3d3b'
  on-primary-container: '#fff6f5'
  inverse-primary: '#ffb3ad'
  secondary: '#7c5817'
  on-secondary: '#ffffff'
  secondary-container: '#fecc81'
  on-secondary-container: '#795514'
  tertiary: '#00636d'
  on-tertiary: '#ffffff'
  tertiary-container: '#007e8a'
  on-tertiary-container: '#e8fcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#900b16'
  secondary-fixed: '#ffddaf'
  secondary-fixed-dim: '#efbf74'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#614000'
  tertiary-fixed: '#95f1fe'
  tertiary-fixed-dim: '#78d4e1'
  on-tertiary-fixed: '#001f23'
  on-tertiary-fixed-variant: '#004f57'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
  text-primary: '#241715'
  text-secondary: '#4E4847'
  border-muted: '#A0A3A5'
  border-structural: '#878F9F'
  ink-black: '#4A2E26'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 42px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 12px
  citation:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  panel-padding: 20px
---

## Brand & Style

This design system is engineered for the **Digitálna bibliografia Spravodaj SSS**, a digital archive serving researchers, historians, and speleologists. The personality is **authoritative, institutional, and utilitarian**, eschewing contemporary digital trends in favor of timeless academic rigor.

The visual direction follows a **Modern Institutional** approach:
- **Seriousness:** Every element is optimized for information density and long-form reading.
- **Archival Textures:** A primary background of `gainsboro` provides a softer, paper-like quality compared to harsh digital white, reducing eye strain during deep research.
- **Functional Hierarchy:** Use of bold borders and high-contrast typography to clearly delineate metadata from content.
- **Tactile Reliability:** UI elements should feel mechanical and solid, emphasizing the "tool" nature of the application.

## Colors

The palette is strictly derived from archival aesthetics, utilizing earth tones and iron-oxide accents.

- **Primary Background:** `#E5E3E3` (Gainsboro). This is the foundation of the UI. Pure white (`#FFFFFF`) is reserved exclusively for document previews or print-ready exports.
- **Primary Text:** `#241715`. A deep, warm black that provides maximum legibility against the gainsboro background.
- **Main Accent:** `#CE3D3B` (Firebrick). Used for critical actions, links, and active states. It signals importance without appearing playful.
- **Secondary Accent:** `#CC9F58` (Peru). Reserved for metadata headers, categories, and distinguishing small elements in the bibliographic records.
- **Structural UI:** `#A0A3A5` and `#878F9F` are used for borders, dividers, and panel backgrounds to create depth without using shadows.

## Typography

The typographic system utilizes a classic pairing of a sturdy Serif for hierarchy and a neutral Sans-serif for data density.

- **Headlines (Source Serif 4):** Chosen for its academic authority. It maintains readability in large formats and conveys an archival feel.
- **Body & Data (Inter):** Used for all search results, metadata tables, and system labels. It is highly legible even at small sizes, which is essential for bibliographic lists.
- **Hierarchy:** Use `label-lg` (uppercase with letter spacing) for section headers such as "METADATA" or "DOCUMENT DETAILS" to provide a clear structural break.
- **Citations:** Bibliographic citations should be rendered in `body-md` or the specific `citation` style to distinguish them from surrounding UI text.

## Layout & Spacing

The layout uses a **Fixed Grid** model on desktop to ensure content remains readable and does not stretch excessively on wide monitors, maintaining the feel of a physical ledger or book.

- **Grid:** 12-column system with 24px gutters.
- **Rhythm:** A strict 4px baseline grid ensures vertical alignment across multi-column data views.
- **Panel System:** Content is organized into "Panels." These panels use `#878F9F` for 1px borders and are slightly recessed or elevated through color rather than shadow.
- **Density:** High-density layouts are preferred. Minimize whitespace between list items in search results to allow researchers to scan more records at once.
- **Mobile:** Transition to a single-column fluid layout with 16px side margins.

## Elevation & Depth

This system avoids ambient shadows and blurs. Depth is communicated through **Tonal Layering** and **Structural Outlines**:

- **Borders:** 1px solid borders using `border-structural` (`#878F9F`) define the primary containers.
- **Surface Tiers:**
    - Level 0: `gainsboro` (Main Background)
    - Level 1: `lightslategray` (Sidebars or Utility Bars)
    - Level 2: `white` (Only for document content/PDF view areas)
- **Active States:** Instead of elevation, active items use a 2px interior border or a solid `firebrick` left-edge accent to indicate selection.

## Shapes

To maintain a scholarly and "hard-tooled" aesthetic, all UI elements use **Sharp (0px) corners**. This includes buttons, input fields, panels, and dropdowns. This reinforces the institutional nature of the archive and maximizes the use of screen real estate.

## Components

### Buttons
- **Primary:** Solid `firebrick` background, `white` text. No rounded corners. High contrast.
- **Secondary:** Transparent background, 1px border of `ink-black`, `ink-black` text.
- **Hover/Active:** Darken the background color by 10%; avoid transitions that feel too "soft" or slow.

### Input Fields
- **Search & Forms:** 1px solid `border-structural` background. Use `white` for the field interior to clearly indicate "editability" against the `gainsboro` page.
- **Focus State:** 2px solid `firebrick` outline. No glow.

### Bibliographic Cards & Lists
- **Cards:** Simple 1px borders. Title in `Source Serif 4` (Firebrick), Metadata in `Inter` (Secondary Text).
- **Citations:** Blocks with a 4px left-border of `peru` (`#CC9F58`) to indicate a "quoted" or "copyable" section.

### Metadata Chips
- Small, rectangular blocks with `lightslategray` backgrounds and `text-primary` labels. Used for tags like "Year," "Author," or "Location."

### Tabs & Navigation
- Top-level navigation uses `label-lg` typography. Active tabs are indicated by a solid 3px `firebrick` bottom border.